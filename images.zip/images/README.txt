После запуска python download.py здесь появятся скриншоты.
